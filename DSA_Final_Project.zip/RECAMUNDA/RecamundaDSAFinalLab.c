#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <math.h>
#define MAX_SIZE 1000

// part 1
void welcomeDSA();
void intro();
void mainmenu();
void Quit();

// part 2
void LinearStruct();
void NonLinearStruct();
void Others();

// LinearStructure
void Arrays();
void Stacks();
void Queues();
void LinkedLists();

// A R R A Y S
// Searching
void LinearSearch();
void BinarySearch();
// Sorting
void SelectionSort();
void BubbleSort();

// String Arrays
void Strings();

// String Processing
void Traversal();
void Insertion();
void Deletion();
void Str_Sorting();
void Str_Searching();
void Merging();

// STACKS
void InfixToPostfix();
void InfixToPrefix();
void PostfixToInfix();
void PostfixToPrefix();
void PrefixToInfix();
void PrefixToPostfix();

// QUEUES
void QueueFunction();

// LinkedLists
void LinkedListFunction();
void create();
void display();
void insert_begin();
void insert_end();
void insert_pos();
void delete_begin();
void delete_end();
void delete_pos();

// Others
void fibonacci();
void factorial();
void quadratic();
void gcd();

int main()
{
    void welcomeDSA();
    {
        printf("\t\t\t\t\t\t\t    |************************************************************************|\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~W E L C O M E~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t        T O\t\t\t\t     |\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    |         D A T A  S T R U C T U R E S  A N D  A L G O R I T H M S\t     |\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t        B Y\t\t\t\t     |\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    | \t\t\t      RUSSEL JAMES R. RECAMUNDA\t\t\t     |\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    | \t\t          BACHELOR OF INFORMATION TECHNOLOGY\t\t     |\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    |~~~~~~~~~~~~~~~~~~~~~~~~~~~~2ND YEAR BLOCK - C~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
        printf("\t\t\t\t\t\t\t    | \t\t\t\t\t\t\t\t\t     | \n");
        printf("\t\t\t\t\t\t\t    |************************************************************************|\n");

        printf("\n\t\t\t\t\t\t\t\t\t\t     Press enter to continue...");
        getchar();
        system("cls");

        intro();
    }
}

void intro()
{
    printf("\t\t\t\t\t\t|~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~|\n");
    printf("\t\t\t\t\t\t|          W H A T  I S  D A T A  S T R U C T U R E  A N D  A L G O R I T H M S ?         |\n");
    printf("\t\t\t\t\t\t|               -> Data structures are objects generated to store data and                |\n");
    printf("\t\t\t\t\t\t|              algorithms are a set of instructions to perform specific task              |\n");
    printf("\t\t\t\t\t\t|                    by using the data structures and there are kinds of                  |\n");
    printf("\t\t\t\t\t\t|             data structures which are linear and non-linear data structure.             |\n");
    printf("\t\t\t\t\t\t|     |=============================================================================|     |\n");
    printf("\t\t\t\t\t\t|     |      =====L  I  N  E  A  R - D  A  T  A - S  T  R  U  C  T  U  R  E=====    |     |\n");
    printf("\t\t\t\t\t\t|     |        Data structure where data elements are arranged sequentially or      |     |\n");
    printf("\t\t\t\t\t\t|     |       linearly where each and every element is attached to its previous     |     |\n");
    printf("\t\t\t\t\t\t|     |        and next adjacent is called a linear data structure. In linear       |     |\n");
    printf("\t\t\t\t\t\t|     |     data structure, single level is involved. Therefore, we can traverse    |     |\n");
    printf("\t\t\t\t\t\t|     |     all the elements in single run only. It's easy to implement because     |     |\n");
    printf("\t\t\t\t\t\t|     |        computer memory is arranged in a linear way. Its examples are        |     |\n");
    printf("\t\t\t\t\t\t|     |                     array, stack, queue, linked list, etc.                  |     |\n");
    printf("\t\t\t\t\t\t|     |=============================================================================|     |\n");
    printf("\t\t\t\t\t\t|     |  ===N  O  N - L  I  N  E  A  R - D  A  T  A - S  T  R  U  C  T  U  R  E===  |     |\n");
    printf("\t\t\t\t\t\t|     |      Data structures where data elements are not arranged sequentially      |     |\n");
    printf("\t\t\t\t\t\t|     |   or linearly are called non-linear data structures. In a non-linear data,  |     |\n");
    printf("\t\t\t\t\t\t|     |   single level is not involved. Therefore, we can't traverse all elements   |     |\n");
    printf("\t\t\t\t\t\t|     |   in single run only. Non-linear data structures are not easy to implement  |     |\n");
    printf("\t\t\t\t\t\t|     |     in comparison to linear data structure. It utilizes computer memory     |     |\n");
    printf("\t\t\t\t\t\t|     |            efficiently in comparison to a linear data structure.            |     |\n");
    printf("\t\t\t\t\t\t|     |                      Its examples are trees and graphs.                     |     |\n");
    printf("\t\t\t\t\t\t|     |=============================================================================|     |\n");
    printf("\t\t\t\t\t\t|~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~|\n");

    printf("\n\t\t\t\t\t\t\t\t\t\tPress enter to continue...");
    getchar();
    system("cls");

    mainmenu();
}

void mainmenu()
{
    printf("\t\t\t\t\t\t\t   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|");
    printf("\n\t\t\t\t\t\t\t   *\t\t\t\t\t\t\t\t      *");
    printf("\n\t\t\t\t\t\t\t   *~~~~~D I S C U S S I O N S  I N  D A T A  S T R U C T U R E S~~~~~*\n");
    printf("\t\t\t\t\t\t\t   |\t\t\t\t\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t\t   *\t\t   [1] LINEAR DATA STRUCTURE\t\t\t      *\n");
    printf("\t\t\t\t\t\t\t   *\t\t   [2] NON-LINEAR DATA STRUCTURE\t\t      *\n");
    printf("\t\t\t\t\t\t\t   |\t\t   [3] OTHERS\t\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t\t   *\t\t   [4] Quit\t\t\t\t\t      *\n");
    printf("\t\t\t\t\t\t\t   *\t\t\t\t\t\t\t\t      *\n");
    printf("\t\t\t\t\t\t\t   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int detect;
    printf("\n\t\t\t\t\t\t\t\t      Select your choice then enter to proceed...");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        LinearStruct();
    }
    else if (detect == 2)
    {
        system("cls");
        NonLinearStruct();
    }
    else if (detect == 3)
    {
        system("cls");
        Others();
    }
    else if (detect == 4)
    {
        system("cls");
        Quit();
    }
}

void LinearStruct()
{
    printf("\t\t\t\t\t\t  |*******************************************************************************************|\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t\t\t\t\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |~~~~~~LINEAR DATA STRUCT~~~~~~|\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |       [1] ARRAYS             |\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |       [2] STACKS             |\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |       [3] QUEUES             |\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |       [4] LINKED LISTS       |\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |       [5] Return             |\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |       [6] Quit               |\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t        |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t\t\t\t\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t  |*******************************************************************************************|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t Input your choice then enter: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        Arrays();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
    else if (detect == 3)
    {
        system("cls");
        Queues();
    }
    else if (detect == 4)
    {
        system("cls");
        LinkedLists();
    }
    else if (detect == 5)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 6)
    {
        system("cls");
        Quit();
    }
}
void NonLinearStruct()
{
    printf("\t\t|*********************************************************************************************|\n");
    printf("\t\t|\t\t\t\t |~~~~~NON-LINEAR STRUCT~~~~~|\t\t\t\t      |\n");
    printf("\t\t|\t\t\t\t | TREES<Under Construction> |\t\t\t\t      |\n");
    printf("\t\t|\t\t\t\t | GRAPHS<Under Construction>|\t\t\t\t      |\n");
    printf("\t\t|\t\t\t\t |~~~~~~~~~~~~~~~~~~~~~~~~~~~|\t\t\t\t      |\n");
    printf("\t\t|*********************************************************************************************|\n");

    printf("\t\t\t\t\t\t Press a key to return...");

    getch();
    system("cls");
    mainmenu();
}

void Others()
{
    printf("\t\t\t\t\t\t|*********************************************************************************************|\n");
    printf("\t\t\t\t\t\t|\t\t\t      W H A T  I S  R E C U R S I O N ?\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|  Recursion is the process which comes into existence when a function calls a copy of itself |\n");
    printf("\t\t\t\t\t\t| to work on a smaller problem. Any function which calls itself is called recursive function, |\n");
    printf("\t\t\t\t\t\t|  and such function calls are called recursive calls. Recursion involves several numbers of  |\n");
    printf("\t\t\t\t\t\t|  recursive calls. However, it is important to impose a termination condition of recursion.  |\n");
    printf("\t\t\t\t\t\t|     Recursion code is shorter than iterative code however it is difficult to understand.    |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |~~~~~O T H E R S~~~~~|\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   | (R E C U R S I V E) |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    [1] FIBONACCI    |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    [2] FACTORIAL    |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    [3] QUADRATIC    |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    [4] GCD          |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    [5] Return       |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    [6] Quit         |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |~~~~~~~~~~~~~~~~~~~~~|\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|*********************************************************************************************|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t Input your choice then enter: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        fibonacci();
    }
    else if (detect == 2)
    {
        system("cls");
        factorial();
    }
    else if (detect == 3)
    {
        system("cls");
        quadratic();
    }
    else if (detect == 4)
    {
        system("cls");
        gcd();
    }
    else if (detect == 5)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 6)
    {
        system("cls");
        Quit();
    }
}

void Arrays()
{
    printf("\t\t\t\t\t\t  |*********************************************************************************************|\n");
    printf("\t\t\t\t\t\t  |      SEARCHING - locating a particular element in a collection of elements or in array.     |\n");
    printf("\t\t\t\t\t\t  |               SORTING - Arranging the data in ascending or descending order.                |\n");
    printf("\t\t\t\t\t\t  |               ARRAY - is a data structure that contains a group of elements.                |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t\t\t\t\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |~~~~~~~A R R A Y~~~~~~~|\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |      (Searching)      |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |   [1] LINEAR SEARCH   |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |   [2] BINARY SEARCH   |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |       (Sorting)       |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |   [3] SELECTION SORT  |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |   [4] BUBBLE SORT     |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |                       |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |     [5] STRINGS       |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |                       |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |      [6] Return       |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |      [7] Main Menu    |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |      [8] Quit         |\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t     |~~~~~~~~~~~~~~~~~~~~~~~|\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |\t\t\t\t\t\t\t\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t  |*********************************************************************************************|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t      Select your choice: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        LinearSearch();
    }
    else if (detect == 2)
    {
        system("cls");
        BinarySearch();
    }
    else if (detect == 3)
    {
        system("cls");
        SelectionSort();
    }
    else if (detect == 4)
    {
        system("cls");
        BubbleSort();
    }
    else if (detect == 5)
    {
        system("cls");
        Strings();
    }
    else if (detect == 6)
    {
        system("cls");
        LinearStruct();
    }
    else if (detect == 7)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 8)
    {
        system("cls");
        Quit();
    }
}

void Strings()
{
    printf("\t\t\t\t\t\t\t   |=====================================================================|\n");
    printf("\t\t\t\t\t\t\t   |\t\t\t  W H A T  I S  S T R I N G ?\t\t\t |\n");
    printf("\t\t\t\t\t\t\t   |\t    -> A string is generally considered as a data type\t\t |\n");
    printf("\t\t\t\t\t\t\t   |\t      and is often implemented as an array data structure\t |\n");
    printf("\t\t\t\t\t\t\t   |\t        of bytes (or words) that stores a sequence of\t\t |\n");
    printf("\t\t\t\t\t\t\t   |\t     elements, typically characters, using some character\t |\n");
    printf("\t\t\t\t\t\t\t   |\t     encoding. String may also denote more general arrays\t |\n");
    printf("\t\t\t\t\t\t\t   |\t      or other sequence (list) data types and structures\t |\n");
    printf("\t\t\t\t\t\t\t   |\t\t\t\t\t\t\t\t\t |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |~~~~~~~S T R I N G S~~~~~~~|\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |                           |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [1] TRAVERSAL        |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [2] INSERTION        |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [3] DELETION         |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [4] SORTING          |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [5] SEARCHING        |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [6] MERGING          |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |                           |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [7] Return           |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [8] Main Menu        |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |      [9] Quit             |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |                           |\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t        |~~~~~~~~~~~~~~~~~~~~~~~~~~~|\t\t         |\n");
    printf("\t\t\t\t\t\t\t   |\t\t\t\t\t\t\t\t\t |\n");
    printf("\t\t\t\t\t\t\t   |=====================================================================|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t   Select your choice: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        Traversal();
    }
    else if (detect == 2)
    {
        system("cls");
        Insertion();
    }
    else if (detect == 3)
    {
        system("cls");
        // Deletion();
    }
    else if (detect == 4)
    {
        system("cls");
        Str_Sorting();
    }
    else if (detect == 5)
    {
        system("cls");
        // Str_Searching();
    }
    else if (detect == 6)
    {
        system("cls");
        Merging();
    }
    else if (detect == 7)
    {
        system("cls");
        Arrays();
    }
    else if (detect == 8)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 9)
    {
        system("cls");
        Quit();
    }
}

void Stacks()
{
    printf("\t\t\t\t\t\t|***********************************************************************************************|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t     W H A T  I S  S T A C K ?\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t   -> A stack is a logical concept that consists of a set of similar elements.\t\t|\n");
    printf("\t\t\t\t\t\t|\t   The term is often used in programming and memory organization in computers.\t\t|\n");
    printf("\t\t\t\t\t\t|\t   Programming stacks are based on the principle of last in first out (LIFO),\t\t|\n");
    printf("\t\t\t\t\t\t|\t   a commonly used type of data abstract that consists of two major operations\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t    which are the push and pop.\t\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t INFIX - Infix expression is an expression in which the operator\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t         is in the middle of operands, like operand operator operand.\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t PREFIX -  An expression is called the prefix expression if the\t\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t         operator appears in the expression before the operands.\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t POSTFIX - Postfix expression is an expression in which the operator\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t         is after operands, like operand operator. They are easily\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t         computed by the system but are not human readable.\t\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |~~~~~~~~~S T A C K S~~~~~~~|\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |                           |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    1. Infix to Postfix    |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    2. Infix to Prefix     |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    3. Postfix to Infix    |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    4. Postfix to Prefix   |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    5. Prefix to Infix     |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |    6. Prefix to Postfix   |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |                           |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |         7. Return         |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |         8. Quit           |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |                           |\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |~~~~~~~~~~~~~~~~~~~~~~~~~~~|\t\t\t        |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("\t\t\t\t\t\t|***********************************************************************************************|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t\tSelect your choice: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        InfixToPostfix();
    }
    else if (detect == 2)
    {
        system("cls");
        InfixToPrefix();
    }
    else if (detect == 3)
    {
        system("cls");
        PostfixToInfix();
    }
    else if (detect == 4)
    {
        system("cls");
        PostfixToPrefix();
    }
    else if (detect == 5)
    {
        system("cls");
        PrefixToInfix();
    }
    else if (detect == 6)
    {
        system("cls");
        PrefixToPostfix();
    }
    else if (detect == 7)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 8)
    {
        system("cls");
        Quit();
    }
}

void Queues()
{
    printf("\t\t\t\t\t\t|*********************************************************************************************|\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |~~~~~~~Q U E U E S~~~~~~~|\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |   1. Queue Operation    |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |       2. Main Menu      |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |       3. Quit           |\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t\t   |~~~~~~~~~~~~~~~~~~~~~~~~~|\t\t\t\t      |\n");
    printf("\t\t\t\t\t\t|*********************************************************************************************|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t       Select your choice: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        QueueFunction();
    }
    else if (detect == 2)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 3)
    {
        system("cls");
        Quit();
    }
}

void LinkedLists()
{
    printf("\t\t\t\t\t\t|*********************************************************************************************|\n");
    printf("\t\t\t\t\t\t|\t\t\t      |~~~~~~~L I N K E D  L I S T S~~~~~~~|\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t      |       1. Linked List Function      |\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t      |            2. Main Menu            |\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t      |            3. Quit                 |\t\t\t      |\n");
    printf("\t\t\t\t\t\t|\t\t\t      |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\t\t\t      |\n");
    printf("\t\t\t\t\t\t|*********************************************************************************************|\n");

    int detect;
    printf("\t\t\t\t\t\t\t\t\t\t       Select your choice: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        LinkedListFunction();
    }
    else if (detect == 2)
    {
        system("cls");
        mainmenu();
    }
    else if (detect == 3)
    {
        system("cls");
        Quit();
    }
}

// Linear Structure Array Codes
void LinearSearch()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO=================== L I N E A R  S E A R C H ===================O\n");
    printf("\t|       is a sequential searching algorithm where we start       |\n");
    printf("\tO        from one end and check every element of the list        O\n");
    printf("\t|     until the desired element is found. It is the simplest     |\n");
    printf("\tO                     searching algorithm.                       O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int val;
    int num;

    printf("\n\n\tInput the number size of array: ");
    scanf("%d", &num);

    int array[num];
    int temp[num];
    printf("\n\tEnter array elements: ");
    for (int i = 0; i < num; ++i)
        scanf("%d", &array[i]);

    printf("\n\tEnter the element you want to search: ");
    scanf("%d", &val);

    int i;
    int counter = 0;
    for (i = 0; i < num; ++i)
        if (array[i] == val)
        {
            temp[counter] = i;
            counter++;
        }

    for (i = 0; i < counter; ++i)
    {
        printf("\n\n\n\n\n\n\n");
        printf("\n\tArray Element is found at index position %d\n", temp[i]);
    }
    if (counter == 0)
        printf("\n\n\n\tThe Element you are searching cannot be found\n");
    else
        printf("\n\tThe search key is present %d times in the array\n", counter);

    printf("\n\t*===============================*===============================*");
    printf("\n\t|        [1]. Rerun Again       |          [2]. Return          |");
    printf("\n\t*===============================*===============================*");

    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        LinearSearch();
    }
    else if (detect == 2)
    {
        system("cls");
        Arrays();
    }
}

void BinarySearch()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO=================== B I N A R Y  S E A R C H ===================O\n");
    printf("\t|  Searches for the element by comparing it with the middle item |\n");
    printf("\tO    of the sorted array. If a match occurs, index is returned,  O\n");
    printf("\t|   else the searching area is reduced appropriately to either   |\n");
    printf("\tO            the upper half or lower half of the array.          O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int num;
    int val;
    printf("\n\n\tInput the number size of array: ");
    scanf("%d", &num);

    int array[num];
    printf("\n\tEnter the array elements: ");
    for (int i = 0; i < num; i++)
        scanf("%d", &array[i]);

    printf("\n\tEnter the element you want to search: ");
    scanf("%d", &val);

    int first, last, center;
    first = 0;
    last = num - 1;
    center = (first + last) / 2;

    while (first <= last)
    {
        if (array[center] < val)
            first = center + 1;
        else if (array[center] == val)
        {
            printf("\n\n\n\n\n\n\n");
            printf("\n\tThe element %d is found at index position %d. \n", val, center + 1);
            break;
        }
        else
            last = center - 1;
        center = (first + last) / 2;
    }
    if (first > last)
        printf("\n\n\n\n\n\tArray Element Not found! The element %d isn't present in the array list. \n", val);

    printf("\n\t*===============================*===============================*");
    printf("\n\t|        [1]. Rerun Again       |          [2]. Return          |");
    printf("\n\t*===============================*===============================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        BinarySearch();
    }
    else if (detect == 2)
    {
        system("cls");
        Arrays();
    }
}

void SelectionSort()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO==================== S E L E C T I O N  S O R T I N G ===================O\n");
    printf("\t|  Selection sort is a simple sorting algorithm which finds the smallest  |\n");
    printf("\tO   element in the array and exchanges it with the element in the first   O\n");
    printf("\t|  position. Then finds the second smallest element and exchanges it with |\n");
    printf("\tO the element in the second position and continues until it's all sorted. O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int size;
    int min;
    int temp;

    printf("\n\n\tInput the size of array: ");
    scanf("%d", &size);

    int array[size];

    printf("\n\tEnter array elements: ");
    for (int i = 0; i < size; i++)
        scanf("%d", &array[i]);

    for (int i = 0; i < size - 1; i++)
    {
        min = i;

        for (int j = i + 1; j < size; j++)
        {
            if (array[j] < array[min])
                min = j;
        }

        if (min != i)
        {
            temp = array[i];
            array[i] = array[min];
            array[min] = temp;
        }
    }
    printf("\n\n\n\n\n\n\n");
    printf("\tOutput of Selection Sort of Array: ");
    for (int i = 0; i < size; i++)
        printf("%d ", array[i]);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        SelectionSort();
    }
    else if (detect == 2)
    {
        system("cls");
        Arrays();
    }
}

void BubbleSort()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO================================ B U B B L E  S O R T I N G =============================O\n");
    printf("\t|     Bubble Sort in Data Structure is one of the easiest sorting algorithm being used.   |\n");
    printf("\tO     The idea behind this algorithm is to repeatedly compare the elements one by one     O\n");
    printf("\t|     and swap the adjacent elements to bring them in the correct sorted order. Thus if   |\n");
    printf("\tO there are n number of elements in the array, each element will undergo n-1 comparisons. O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int i, j;
    int size;
    int temp;

    printf("\n\n\tInput the size of array: ");
    scanf("%d", &size);

    int array[size];

    printf("\n\tEnter array elements: ");
    for (i = 0; i < size; i++)
        scanf("%d", &array[i]);

    for (i = 1; i < size; ++i)

        for (j = 0; j < (size - i); ++j)
        {
            if (array[j] > array[j + 1])
            {
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    printf("\n\n\n\n\n\n\n");
    printf("\tOutput of Bubble Sort of Array: ");
    for (i = 0; i < size; ++i)
        printf("%d ", array[i]);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        BubbleSort();
    }
    else if (detect == 2)
    {
        system("cls");
        Arrays();
    }
}

void Traversal()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO======================= T R A V E R S A L ======================O\n");
    printf("\t| Traversing in the data structure is a very important operation |\n");
    printf("\tO that can be performed on any data structure. Traversing means  O\n");
    printf("\t|  systematically visiting every element of it. It is a process  |\n");
    printf("\tO     in which each element of a data structure is accessed.     O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    char strings[MAX_SIZE][MAX_SIZE];
    int i, num;

    printf("\n\n\tEnter the number of string values: ");
    scanf("%d", &num);

    printf("\n\t=====Enter strings=====\n");
    for (i = 0; i < num; i++)
    {
        printf("\tString[%d]: ", i + 1);
        getchar();
        scanf("%[^\n]s", strings[i]);
    }

    printf("\n\n\n\n\n\n\n");
    printf("\tThe Output of strings are:\n");
    for (i = 0; i < num; i++)
    {
        printf("\tOUTPUT[%d]: %s\n", i + 1, strings[i]);
    }

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");

    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        Traversal();
    }
    else if (detect == 2)
    {
        system("cls");
        Strings();
    }
}

void Insertion()
{
    // int size;
    char str[MAX_SIZE];
    char wrd[MAX_SIZE];
    char cpy[MAX_SIZE];
    int pos = 0, lstr = 0, i = 0;
    int trm = 0;
    int num, x, g, s, o;

    printf("Enter the string values:");
    gets(str);
    // scanf("%d", &size);

    printf("\nEnter substring to be added in the string: ");
    // scanf("%s", &wrd);
    gets(wrd);

    printf("\nEnter the position where the item has to be inserted: ");
    scanf("%d", &pos);
    lstr = strlen(str);
    num = strlen(wrd);
    i = 0;

    while (i <= lstr)
    {
        cpy[i] = str[i];
        i++;
    }
    s = num + lstr;
    o = pos + num;

    for (i = pos; i < s; i++)
    {
        x = cpy[i];
        if (trm < num)
        {
            str[i] = wrd[trm];
            trm = trm + 1;
        }
        str[o] = x;
        o = o + 1;
    }

    printf("\nThe output of the string is now: %s", str);
}

void Deletion()
{
    int num, pos;
    char str[MAX_SIZE];

    printf("Add your string values: ");
    gets(str);
    fflush(stdin);

    printf("\nInput the starting number position for deleting the characters: ");
    scanf("%d", &pos);

    printf("\nInput how many number of characters are going to be deleted in the string: ");
    scanf("%d", &num);

    int i, j;
    for (i = 0, j = 0; str[i] != '\0'; i++, j++)
    {
        if (i == (pos - 1))
        {
            i = i + num;
        }
        str[j] = str[i];
    }
    str[j] = '\0';
    printf("\nAfter Deletion The Output Is Now: ");
    puts(str);
}

void Str_Sorting()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO======================= S O R T I N G ======================O\n");
    printf("\t|  Sorting a string is defined as string arrangement either  |\n");
    printf("\tO     in ascending or descending order or any given order    O\n");
    printf("\t|    is known as sorting in C which is nothing but getting   |\n");
    printf("\tO   the strings given in proper order or given order can be  O\n");
    printf("\t|  said as the strings are sorted in the given or specified  |\n");
    printf("\tO  specified arrangement. Different sorting can be use here. O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    char name[MAX_SIZE][MAX_SIZE], temp[MAX_SIZE];
    int num, i, j;

    printf("Input length size of strings: ");
    scanf("%d", &num);

    printf("\nInput %d strings to sort in order: \n", num);
    for (i = 0; i <= num; i++)
    {

        fgets(name[i], sizeof name, stdin);
    }

    for (i = 1; i <= num; i++)
        for (j = 0; j <= num - i; j++)
            if (strcmp(name[j], name[j + 1]) > 0)
            {
                strcpy(temp, name[j]);
                strcpy(name[j], name[j + 1]);
                strcpy(name[j + 1], temp);
            }
    printf("\nThe sorted order of the strings are now: ");
    for (i = 0; i <= num; i++)
        printf("%s\n", name[i]);
}

void Str_Searching()
{
    char str[MAX_SIZE], wrd[MAX_SIZE];
    int num, pos, val, lngth, chr[MAX_SIZE];
    int found = 0, trm = 0, k = 0;

    printf("Input string values: ");
    scanf("%s", &str);

    printf("\nInput a word to be searched for in the string: ");
    scanf("%s", &wrd);

    for (pos = 0; str[pos]; pos++)
    {
        if (str[pos] == ' ')
        {
            chr[k++] = pos;
        }
    }
    chr[k++] = pos;
    val = 0;

    for (pos = 0; pos < k; pos++)
    {
        num = chr[pos] - val;
        if (num == strlen(wrd))
        {
            trm = 0;
            for (lngth = 0; wrd[lngth]; lngth++)
            {
                if (str[lngth + val] == wrd[lngth])
                {
                    trm++;
                }
            }
            if (trm == strlen(wrd))
            {
                found++;
                printf("\nThe word '%s' is searched and found at location = %d", wrd, val);
            }
        }

        val = chr[pos] + 1;
    }
    if (trm != strlen(wrd))
    {
        printf("\nThe word your searching for is not present!");
    }
}

void Merging()
{
    int i, size;
    char string[MAX_SIZE][MAX_SIZE];

    printf("Input the number of strings: ");
    scanf("%d", &size);

    for (i = 0; i < size; i++)
    {
        printf("\nInput string %d: ", i + 1);
        scanf("%s", &string[i]);
    }

    printf("\nResult of strings merge together: ");
    for (i = 0; i <= size; i++)
    {
        printf(" %s", &string[i]);
    }
}

// Linear Structure of Stacks Codes
char stack[MAX_SIZE], str[MAX_SIZE];

int top = -1;

void push(char elem)
{
    stack[++top] = elem;
}

char pop()
{
    return (stack[top--]);
}

int pr(char symbol)
{
    if (symbol == '^')
    {
        return (3);
    }
    else if (symbol == '*' || symbol == '/')
    {
        return (2);
    }
    else if (symbol == '+' || symbol == '-')
    {
        return (1);
    }
    else
    {
        return (0);
    }
}

// Infix to Postfix Conversion
void InfixToPostfix()
{
    char infix[MAX_SIZE], postfix[MAX_SIZE], ch, elem;
    int i = 0, k = 0;
    printf("Enter Infix Expression: ");
    scanf("%s", infix);
    push('#');
    while ((ch = infix[i++]) != '\0')
    {
        if (ch == '(')
            push(ch);
        else if (isalnum(ch))
            postfix[k++] = ch;
        else if (ch == ')')
        {
            while (stack[top] != '(')
                postfix[k++] = pop();
            elem = pop();
        }
        else
        {
            while (pr(stack[top]) >= pr(ch))
                postfix[k++] = pop();
            push(ch);
        }
    }
    while (stack[top] != '#')
        postfix[k++] = pop();
    postfix[k] = '\0';
    printf("\n\n\n\n\nGiven The Infix Expression: %s\n", infix);
    printf("\nThe Postfix Expression is now: %s\n", postfix);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        InfixToPostfix();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
}

// Infix To Prefix Conversion
void InfixToPrefix()
{
    char infx[MAX_SIZE], prfx[MAX_SIZE], ch, elem;
    int i = 0, k = 0;
    printf("Enter Infix Expression: ");
    scanf("%s", infx);
    push('#');
    strrev(infx);
    while ((ch = infx[i++]) != '\0')
    {
        if (ch == ')')
            push(ch);
        else if (isalnum(ch))
            prfx[k++] = ch;
        else if (ch == '(')
        {
            while (stack[top] != ')')
                prfx[k++] = pop();
            elem = pop();
        }
        else
        {
            while (pr(stack[top]) >= pr(ch))
                prfx[k++] = pop();
            push(ch);
        }
    }
    while (stack[top] != '#')
        prfx[k++] = pop();
    prfx[k] = '\0';
    strrev(prfx);
    strrev(infx);

    printf("\n\n\n\nGiven The Infix Expression: %s\n", infx);
    printf("\nThe Prefix Expression is now: %s\n", prfx);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        InfixToPrefix();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
}

// Postfix To Infix Conversion
void PostfixToInfix()
{
    char postfix[MAX_SIZE];
    char infix[MAX_SIZE];
    char op1, op2;
    int l, i, j = 0;

    printf("\nEnter the Postfix Expression : : ");
    scanf("%s", postfix);

    strrev(postfix);
    l = strlen(postfix);
    for (i = 0; i < 50; i++)
    {
        stack[i] = '\0';
    }

    printf("\n\n\n\nThe Infix Expression is now: ");
    for (i = 0; i < l; i++)
    {
        if (postfix[i] == '+' || postfix[i] == '-' || postfix[i] == '*' || postfix[i] == '/' || postfix[i] == '^')
            push(postfix[i]);
        else
        {
            infix[j++] = postfix[i];
            infix[j++] = pop();
        }
    }
    infix[j] = postfix[top--];
    strrev(infix);
    puts(infix);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        PostfixToInfix();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
}

// Postfix to Prefix Conversion
void PostfixToPrefix()
{
    char postfix[MAX_SIZE];
    char tmp[MAX_SIZE];
    int n, i, j = 0;
    char a, b, op;

    printf("Enter the postfix expression: ");
    scanf("%s", postfix);

    n = strlen(postfix);

    for (i = 0; i < MAX_SIZE; i++)
        stack[i] = '\0';
    printf("\n\n\n\nThe Prefix Expression is now: ");

    for (i = n - 1; i >= 0; i--)
    {
        if (pr(postfix[i]))
        {
            push(postfix[i]);
        }
        else
        {
            tmp[j++] = postfix[i];
            while ((top != -1) && (stack[top] == '#'))
            {
                a = pop();
                tmp[j++] = pop();
            }
            push('#');
        }
    }
    tmp[j] = '\0';

    i = 0;
    j = strlen(tmp) - 1;
    char prefix[MAX_SIZE];

    while (tmp[i] != '\0')
    {
        prefix[j--] = tmp[i++];
    }
    printf("%s\n", prefix);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        PostfixToPrefix();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
}

// Prefix to Infix Conversion
void PrefixToInfix()
{
    int n, i;
    char a, b, op;
    printf("Enter the prefix expression: ");
    fflush(stdin);
    gets(str);
    n = strlen(str);
    for (i = 0; i < MAX_SIZE; i++)
        stack[i] = '\0';
    printf("\n\n\n\nThe Infix Expression is now: ");
    for (i = 0; i < n; i++)
    {
        if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/' || str[i] == '^')
        {
            push(str[i]);
        }
        else
        {
            op = pop();
            a = str[i];
            printf("%c%c", a, op);
        }
    }
    printf("%c\n", str[top--]);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        PrefixToInfix();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
}

// Prefix To Postfix Conversion
void PrefixToPostfix()
{
    int n, i, j = 0;
    char c[MAX_SIZE];
    char a, b, op;
    printf("Enter the prefix expression: ");
    fflush(stdin);
    gets(str);

    n = strlen(str);
    for (i = 0; i < MAX_SIZE; i++)
        stack[i] = '\0';
    printf("\n\n\n\nThe Postfix expression is now: ");
    for (i = 0; i < n; i++)
    {
        if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/')
        {
            push(str[i]);
        }
        else
        {
            c[j++] = str[i];
            while ((top != -1) && (stack[top] == '@'))
            {
                a = pop();
                c[j++] = pop();
            }
            push('@');
        }
    }
    c[j] = '\0';
    printf("%s", c);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        PrefixToPostfix();
    }
    else if (detect == 2)
    {
        system("cls");
        Stacks();
    }
}

// Queues
void QueueFunction()
{
    int size, item, choice, i;
    int rear = 0;
    int front = 0;
    int exit = 1;

    printf("\nInput Size of Array: ");
    scanf("%d", &size);
    int arr_queue[MAX_SIZE];
    do
    {
        printf("\n\n Queue");
        printf("\n1.Insert \n2.Remove \n3.Display \n4. Main Menu \nOthers to exit");
        printf("\nEnter Your Choice : ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            if (rear == MAX_SIZE)
                printf("\nQueue Reached Max!!");
            else
            {
                printf("\nEnter The Integer Value to be Insert : ");
                scanf("%d", &item);
                printf("\nPosition : %d , Insert Value  : %d ", rear + 1, item);
                arr_queue[rear++] = item;
            }
            break;
        case 2:
            if (front == rear)
                printf("\nQueue is Empty!");
            else
            {
                printf("\nPosition : %d , Remove Value  : %d ", front, arr_queue[front]);
                front++;
            }
            break;
        case 3:
            printf("\nQueue Size : %d ", rear);
            for (i = front; i < rear; i++)
                printf("\nPosition : %d , Value  : %d ", i, arr_queue[i]);
            break;
        case 4:
            LinearStruct();
        default:
            exit = 0;
            break;
        }
    } while (exit);
}

// Linked Lists
struct node
{
    int info;
    struct node *next;
};
struct node *start = NULL;
void LinkedListFunction()
{
    int choice;
    while (1)
    {
        printf("\n 1.Create");
        printf("\n 2.Display");
        printf("\n 3.Insert at the beginning");
        printf("\n 4.Insert at the end  n");
        printf("\n 5.Insert at specified position");
        printf("\n 6.Delete from beginning");
        printf("\n 7.Delete from the end");
        printf("\n 8.Delete from specified position");
        printf("\n 9.Exit");

        printf("\n\nEnter your choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            create();
            break;
        case 2:
            display();
            break;
        case 3:
            insert_begin();
            break;
        case 4:
            insert_end();
            break;
        case 5:
            insert_pos();
            break;
        case 6:
            delete_begin();
            break;
        case 7:
            delete_end();
            break;
        case 8:
            delete_pos();
            break;

        case 9:
            exit(0);
            break;

        default:
            printf("\n Invalid Choice:n");
            break;
        }
    }
}

void create()
{
    struct node *temp, *ptr;
    temp = (struct node *)malloc(sizeof(struct node));
    if (temp == NULL)
    {
        printf("\nOut of Memory Space:");
        exit(0);
    }
    printf("\nEnter the data value for the node: ");
    scanf("%d", &temp->info);
    temp->next = NULL;
    if (start == NULL)
    {
        start = temp;
    }
    else
    {
        ptr = start;
        while (ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        ptr->next = temp;
    }
}
void display()
{
    struct node *ptr;
    if (start == NULL)
    {
        printf("\nList is empty: ");
        return;
    }
    else
    {
        ptr = start;
        printf("\nThe List elements are: ");
        while (ptr != NULL)
        {
            printf("%dt", ptr->info);
            ptr = ptr->next;
        }
    }
}
void insert_begin()
{
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    if (temp == NULL)
    {
        printf("\nOut of Memory Space:n");
        return;
    }
    printf("\nEnter the data value for the node: ");
    scanf("%d", &temp->info);
    temp->next = NULL;
    if (start == NULL)
    {
        start = temp;
    }
    else
    {
        temp->next = start;
        start = temp;
    }
}
void insert_end()
{
    struct node *temp, *ptr;
    temp = (struct node *)malloc(sizeof(struct node));
    if (temp == NULL)
    {
        printf("\nOut of Memory Space:n");
        return;
    }
    printf("\nEnter the data value for the node: ");
    scanf("%d", &temp->info);
    temp->next = NULL;
    if (start == NULL)
    {
        start = temp;
    }
    else
    {
        ptr = start;
        while (ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        ptr->next = temp;
    }
}
void insert_pos()
{
    struct node *ptr, *temp;
    int i, pos;
    temp = (struct node *)malloc(sizeof(struct node));
    if (temp == NULL)
    {
        printf("\nOut of Memory Space: ");
        return;
    }
    printf("\nEnter the position for the new node to be inserted: ");
    scanf("%d", &pos);
    printf("\nEnter the data value of the node: ");
    scanf("%d", &temp->info);

    temp->next = NULL;
    if (pos == 0)
    {
        temp->next = start;
        start = temp;
    }
    else
    {
        for (i = 0, ptr = start; i < pos - 1; i++)
        {
            ptr = ptr->next;
            if (ptr == NULL)
            {
                printf("\nPosition not found:[Handle with care]\n");
                return;
            }
        }
        temp->next = ptr->next;
        ptr->next = temp;
    }
}
void delete_begin()
{
    struct node *ptr;
    if (ptr == NULL)
    {
        printf("\nList is Empty:\n");
        return;
    }
    else
    {
        ptr = start;
        start = start->next;
        printf("\nThe deleted element is :%dt", ptr->info);
        free(ptr);
    }
}
void delete_end()
{
    struct node *temp, *ptr;
    if (start == NULL)
    {
        printf("\nList is Empty: ");
        exit(0);
    }
    else if (start->next == NULL)
    {
        ptr = start;
        start = NULL;
        printf("\nThe deleted element is: %d", ptr->info);
        free(ptr);
    }
    else
    {
        ptr = start;
        while (ptr->next != NULL)
        {
            temp = ptr;
            ptr = ptr->next;
        }
        temp->next = NULL;
        printf("\nThe deleted element is:%d", ptr->info);
        free(ptr);
    }
}
void delete_pos()
{
    int i, pos;
    struct node *temp, *ptr;
    if (start == NULL)
    {
        printf("\nThe List is Empty:n");
        exit(0);
    }
    else
    {
        printf("\nEnter the position of the node to be deleted: ");
        scanf("%d", &pos);
        if (pos == 0)
        {
            ptr = start;
            start = start->next;
            printf("\nThe deleted element is: %d", ptr->info);
            free(ptr);
        }
        else
        {
            ptr = start;
            for (i = 0; i < pos; i++)
            {
                temp = ptr;
                ptr = ptr->next;
                if (ptr == NULL)
                {
                    printf("\nPosition not Found:");
                    return;
                }
            }
            temp->next = ptr->next;
            printf("\nThe deleted element is: %dt", ptr->info);
            free(ptr);
        }
    }
}

int fib(int num)
{
    if (num <= 1)
        return num;
    return fib(num - 1) + fib(num - 2);
}
void fibonacci()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO======================== F I B O N A C C I =======================O\n");
    printf("\t|  The Fibonacci series is a sequence of numbers in which each can |\n");
    printf("\tO        be generated by adding up the previous two numbers.       O\n");
    printf("\t|      It is also the simplest example of a recursive problem.     |\n");
    printf("\tO  The recursive call, base case, and stopping condition are used. O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int num;

    printf("\n\n\tInput a number for the fibonacci: ");
    scanf("%d", &num);

    printf("\n\n\n\n\n\n\n");

    printf("\tThe of Fibonacci series of number %d is: ", num);
    for (int i = 0; i < num; i++)
        printf("%d ", fib(i + 1));

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");
    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        fibonacci();
    }
    else if (detect == 2)
    {
        system("cls");
        Others();
    }
}

void factorial()
{

    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO=================== F A C T O R I A L ===================O\n");
    printf("\t|   The factorial of a positive integer n, denoted by n!, |\n");
    printf("\tO    is the product of all positive descending integers   O\n");
    printf("\t| less than or equal to n Syntax for factorial number is: |\n");
    printf("\tO        n! = n. (n - 1). (n - 2). (n - 3)....3.2.1.      O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int fact = 1;
    int num;

    printf("\n\n\tInput a number to find the factorial: ");
    scanf("%d", &num);

    printf("\n\n\n\n\n\n\n");

    for (int i = 1; i <= num; i++)
        fact = fact * i;
    printf("\tThe Factorial of the given number %d is %d: ", num, fact);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");

    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        factorial();
    }
    else if (detect == 2)
    {
        system("cls");
        Others();
    }
}

void quadratic()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO==================== Q U A D R A T I C =====================O\n");
    printf("\t| It is represented as ax2 + bx +c = 0, where a, b and c are |\n");
    printf("\tO  the coefficient variable of the equation. The universal   O\n");
    printf("\t| of quadratic equation defines that the value of 'a' cannot |\n");
    printf("\tO  be zero, and the value of x is used to find the roots of  O\n");
    printf("\t| of the quadratic equation (a, b). The roots are defined in |\n");
    printf("\tO three ways: real&distinct, real&equal, and real&imaginary. O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int a, b, c, disc = 0;
    float den = 0, x = 0, x1 = 0, x2 = 0;
    float qe = 0, qe1 = 0, qe2 = 0;

    printf("\n\tPlease enter the values for a:  ");
    scanf("%d", &a);
    printf("\n\tPlease enter the values for b:  ");
    scanf("%d", &b);
    printf("\n\tPlease enter the values for c:  ");
    scanf("%d", &c);

    printf("\n\n\t The values you entered are: %d, %d, %d", a, b, c);

    disc = ((b * b) - 4 * (a * c));
    den = 2 * a;

    printf("\n\n\t The discriminant is: %d", disc);
    printf("\n\n\t The quadratic equation is: %dX^2 + %dx + %d", a, b, c);

    if (disc > 0)
    {
        x1 = (-b + sqrt(disc)) / den;
        x2 = (-b - sqrt(disc)) / den;
        qe = (a * (x * x)) + (b * x) + c;
        qe1 = (a * (x1 * x1)) + (b * x1) + c;
        qe2 = (a * (x2 * x2)) + (b * x2) + c;

        printf("\n\n The first value of x is %.2f \n The second value of x is %.2f. ", x1, x2);

        printf("\n\n For X = %.2f \n qe = %d * (%.2f * %.2f) + %d * %.2f +  %d", x1, a, x1, x1, b, x1, c);
        printf("\n qe = %.2f \n", qe1);

        printf("\n\n For X = %.2f \n qe = %d * (%.2f * %.2f) + %d * %.2f +  %d", x2, a, x2, x2, b, x2, c);
        printf("\n qe = %.2f \n", qe2);
    }
    else if (disc == 0)
    {
        x = (-b / den);
        printf("\n\n The UNIQUE SOLUION is %.2f.", x);
        printf("\n\n For X = %.2f \n qe = %d * (%.2f * %.2f) + %d * %.2f +  %d", x, a, x, x, b, x2, c);
        printf("\n qe = %.2f \n", qe);
    }
    else
        printf("\n\n There is NO REAL SOLUTION");

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");

    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        quadratic();
    }
    else if (detect == 2)
    {
        system("cls");
        Others();
    }
}

void gcd()
{
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");
    printf("\tO============================== G C D ==============================O\n");
    printf("\t|   The GCD is a mathematical term for the Greates Common Divisor   |\n");
    printf("\tO     of two or more numbers. It is the Greatest common divisor     O\n");
    printf("\t|    that completely divides two or more numbers without leaving    |\n");
    printf("\tO                           any remainder.                          O\n");
    printf("\t|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|\n");

    int num1, num2, i, GCD_Num;
    printf("\n\n\tEnter any two numbers: ");
    scanf("%d %d", &num1, &num2);

    for (i = 1; i <= num1 && i <= num2; ++i)
    {
        if (num1 % i == 0 && num2 % i == 0)
            GCD_Num = i;
    }
    printf("\n\n\n\n\tGCD of two numbers %d and %d is %d.", num1, num2, GCD_Num);

    printf("\n\n\t*===========================================================*");
    printf("\n\t|\t\t    [1]. Rerun Again\t\t\t    |");
    printf("\n\t|\t\t    [2]. Return\t\t\t\t    |");
    printf("\n\t*===========================================================*");

    int detect;
    printf("\n\n\t\t\t     Select option: ");
    scanf("%d", &detect);

    if (detect == 1)
    {
        system("cls");
        gcd();
    }
    else if (detect == 2)
    {
        system("cls");
        Others();
    }
}

void Quit()
{
    printf("\n\n\t\t\t\t\t\t     *~*~*~*~* Thank You For Using Our Data Structure and Algorithm System! *~*~*~*~*\n");
    printf("\n\n\t\t\t\t\t\t\t\t     *~*~*~*~*~C O M E B A C K  A G A I N~*~*~*~*~*\n");
}